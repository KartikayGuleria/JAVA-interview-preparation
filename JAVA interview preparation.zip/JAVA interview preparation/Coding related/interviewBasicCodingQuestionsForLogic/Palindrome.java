package interviewCodingQuestions;

public class Palindrome {

	
	
	public static void main(String[] args) {
		
		String s=new String();
		String s1 = new String();
		s="12321";
		char c;
		for(int i=s.length()-1;i>=0;i--) {
			c=s.charAt(i);
			s1=s1+c;
			
			
			
		}
		
		if(s.equals(s1)) {
			System.out.println(  s1+" String is palindrome");
		}
		else {
			System.out.println("Not palindrome");
		}
		
		
	}
}
