package interviewCodingQuestions;

public class FIbonocciSeries {
	static int n1=0,n2=1,n3=0;

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		int count =10;
//		run(count-2);
//	
//
//	}
//	
//	
//	
//	public static void run(int count){
//		
//		if(count>0) {
//			
//			n3=n1+n2;
//			
//			n1=n2;
//			n2=n3;
//			
//			System.out.println(" "+n3);
//			run(count-1);
//			
//			
//		}
//		
//	}
	
	
	public static void main(String[] args) {
		
		int x,y=0;
		
		int z=1;
		
		for(int i=0; i<=10;i++) {
			
		x=y+z;
		y=z;
		z=x;
		
		System.out.println("value of series "+x);
		}
		
		
		
		
		
		
		
		
	}

}
