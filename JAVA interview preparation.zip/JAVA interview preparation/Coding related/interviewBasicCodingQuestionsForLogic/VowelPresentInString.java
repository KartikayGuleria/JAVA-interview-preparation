package interviewCodingQuestions;

public class VowelPresentInString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="kartikay guleria";
		
			if(s.contains("a")|s.contains("e")|s.contains("i")|s.contains("o")|s.contains("u")){
				
				System.out.println("vowel is present");
			}
			else {
				
				System.out.println("vowel is not present");
			}
			
		}
		
	}

