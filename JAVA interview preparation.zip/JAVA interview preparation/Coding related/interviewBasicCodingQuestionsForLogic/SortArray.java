package interviewCodingQuestions;

public class SortArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr= {2,6,3,8,0,10,96};
		 
		for(int i=0;i<=arr.length-1;i++) {
			for(int j=0;j<=arr.length-2;j++) {
			if(arr[j]>arr[j+1]) {
				int val=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=val;
				}
			else {
				continue;
			}
			
		}
		}
		System.out.println("sorted array "+arr);
		
		
		
	}

}
