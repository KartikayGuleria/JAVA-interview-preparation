package interviewCodingQuestions;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ReverseString {

	public static void main(String[] args) {
	
		
		String s= "abcdef";
		char c;
		String reversedString=new String();
		for(int i=s.length()-1;i>=0;i--) {
			
			c=s.charAt(i);
			reversedString=reversedString+c;
			
			
		}
		
		System.out.println("string is : "+s +" reversed is "+reversedString);
		
		
		//method 2
		
		String[] str=new String[] {s};
		   List l  =Arrays.asList(str);
		
		Collections.reverse(l);
		System.out.println("reversed ");


}
}