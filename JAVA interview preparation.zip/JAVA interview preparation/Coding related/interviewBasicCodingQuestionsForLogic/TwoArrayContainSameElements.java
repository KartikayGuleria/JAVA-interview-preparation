package interviewCodingQuestions;

public class TwoArrayContainSameElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr1= {1,2,3,6,5,7,10};
		
		int[] arr2= {2,3,1,5,6,7};
		
		int flag=0;
		for(int i=0;i<=arr1.length-1;i++) {
			for(int j=0;j<=arr2.length-1;j++) {
				if((arr1[i]==arr2[j])&&(arr2[j]==arr1[i])) {
					
					flag=1;
					
				}
				
				else {
					flag=2;
				}
				
				
			}
			
		}
		if(flag==1) {
		System.out.println("same elements are there");
		}
		else {
			System.out.println("no same elements");
		}

	}

}
