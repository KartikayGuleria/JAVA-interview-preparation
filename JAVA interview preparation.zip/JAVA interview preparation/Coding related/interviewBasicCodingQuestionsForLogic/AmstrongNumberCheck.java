package interviewCodingQuestions;

public class AmstrongNumberCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int number=153;
		int num=0;
		int flag=0;
		
		while(number!=0) {
			
			number=number/10;
			flag++;
		}
		number=153;
		Integer c;
		Integer z=0;
		int y=0;
		int size=flag;
		for(int i=0;i<=flag-1;i++) {
			c=number%10;
			number=number/10;
			int valAfterPower=(int) Math.pow(c, size);
			z=z+valAfterPower;
			
		}
		number=153;
		if(z.equals(number)) {
			
			System.out.println("astronomica number");
		}
		else {
			System.out.println("not an astronomica number");
		}

	}

}
