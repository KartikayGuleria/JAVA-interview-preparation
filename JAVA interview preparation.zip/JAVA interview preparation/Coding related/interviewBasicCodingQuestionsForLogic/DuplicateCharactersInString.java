package interviewCodingQuestions;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;


public class DuplicateCharactersInString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String str1 = new String();
		
		str1="kartikay guleria";
		String str=str1.replaceAll(" ", "");
		
		
		
		//char[] array=str1.toCharArray();
		char c;
		
		//method one using hashmap
		
		
		 HashMap<Character,Integer>  map =new HashMap<Character,Integer>();
		 
		for(int i=0;i<=str.length()-1;i++) {
			
			c=str.charAt(i);
		
			if(map.containsKey(c)) {
				map.put(c,map.get(c)+1);
				
			}
			
			else {
				map.put(c,1);
				
			}
			
			
			
		}
		
	
		for(Map.Entry<Character,Integer>  entry : map.entrySet() ) {
			Integer val=entry.getValue();
			
			if(val>1) {
		//		System.out.println(entry.getKey()+" "+entry.getValue());
			}
			
		}
		
		// using java 8
		String val= "kartikay singh";
		String[] val2= val.replaceAll(" ", "").split("");
		
	    List<String>   list1  =Arrays.asList(val2);
	  
	    Map<String,Long>  map1=  list1.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
	    System.out.println(map1);
	          for( Map.Entry<String, Long>  entry : map1.entrySet()) {
	        	  
	        	  if(entry.getValue()>1) {
	        	  System.out.println("{"+entry.getKey()+","+entry.getValue()+"}");
	        	  }
	        	  
	          }
	    
	    
		
		
}
	
	
}
