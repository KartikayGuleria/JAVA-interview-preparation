package interviewCodingQuestions;

public class Swap2numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=2;
		int b=7;
		int c;
		
		c=a;
		a=b;
		b=c;
		
		//without using 3rd number
		
//		a=a+b;
//		b=a-b;
//		a=a-b;
//		
		
		System.out.println("Swiped final values are "+ a +" "+ b);
		
		

	}

}
