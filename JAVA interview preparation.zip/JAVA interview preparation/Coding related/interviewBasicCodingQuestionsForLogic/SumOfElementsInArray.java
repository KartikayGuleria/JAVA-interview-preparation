package interviewCodingQuestions;

public class SumOfElementsInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		int[] arr= {1,4,3,5,7,6,8};
		int x=0;
		
		for(int a:arr) {
			x=x+a;
			
			
		}
		
		System.out.println("Sum of elements is "+x);
	}

}
