package interviewCodingQuestions;

import java.util.Scanner;

public class FactorialInJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Scanner s= new Scanner(System.in);
		
		System.out.println("enter the number to find factorial");
		
		int value =s.nextInt();
		int i=0;
		int x=0;
		int z=1;
		int counter=value/2;    //for repeating the loop n/2 number of times
		for(i=1;i<=counter;i++) {
			
			x=value*(value-1);
			value=value-2;
			z=z*x;
			
			
			
			
		}
		
		
		System.out.println("factorial is "+z);
		
		
		

	}

}
