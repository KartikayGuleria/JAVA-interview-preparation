package interviewCodingQuestions;

import java.util.Scanner;

public class NumberIsPrimeOrNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter the number to check");
		int a = s.nextInt();
		//String st=s.nextLine();    for getting string input
		
		int flag=0;
		
		for(int i=2;i<=a-1;i++) {
			flag =0;
			if(a%i!=0) {
				flag=1;
				
			}
			else {
				flag=2;
				break;
			}
			
		}
		
		if(flag==1) {
			System.out.println("number is prime");
		}
		else {
			
			System.out.println("number is not prime");
		}
		
		
		
		
		
	}

}
