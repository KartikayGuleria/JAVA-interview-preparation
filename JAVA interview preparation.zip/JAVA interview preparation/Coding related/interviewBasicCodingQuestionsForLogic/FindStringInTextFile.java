package interviewCodingQuestions;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FindStringInTextFile {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		
		FindStringInTextFile obj  =new FindStringInTextFile();
		obj.findStringInFile("D:/filetest.txt", "my");

	}
	
	public boolean findStringInFile(String filepath,String str) throws FileNotFoundException {
		
		filepath="D:/filetest.txt";
		str="my";
		
		File file=new File(filepath);
		
		Scanner scanner= new Scanner(file);
		
		//read the file line by line
		int flag=0;
		while(scanner.hasNext()) {
			String line=scanner.nextLine();
			if(line.contains(str)) {
				scanner.close();
				return true;
			}
			
			
		}
		
		scanner.close();
		
		return false;
		
	}

}
