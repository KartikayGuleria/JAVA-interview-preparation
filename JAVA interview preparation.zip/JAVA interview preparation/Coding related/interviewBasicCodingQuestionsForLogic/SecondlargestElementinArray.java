package interviewCodingQuestions;

public class SecondlargestElementinArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr= {3,6,5,8,7,3,5,99,0,100};
		
		for(int i=0;i<=arr.length-1;i++) {
			for(int j=0;j<=arr.length-2;j++) {
				if(arr[j]>arr[j+1]) {
					int x=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=x;
					
				}
				
				
			}
			
		}
		Integer length=arr.length;
		System.out.println("second highest element is "+arr[length-2]);

	}

}
