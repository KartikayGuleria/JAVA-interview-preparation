package interviewCodingQuestions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

public class SortHashMapByValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	HashMap<String,Integer> map =new   HashMap<String,Integer>();
	
	map.put("abc",2);
	map.put("def",5);
	map.put("ghi",9);
	map.put("jkl",0);
	map.put("mno",1);
	map.put("pqr",2);
	
       Set<Entry<String,Integer>>  entryset =map.entrySet();
		
	   List<Entry<String,Integer>> list  = new ArrayList<Entry<String,Integer>>(entryset);
	   
	   Collections.sort(list, new Comparator<Entry<String,Integer>>() {

		@Override
		public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
			// TODO Auto-generated method stub
			return o1.getValue().compareTo(o2.getValue());
		}
	});
	   
	   
	   list.forEach(s->{
		   
		   System.out.println(s.getKey()+" : "+ s.getValue());
		  // System.out.println("values were diplayed above");
		   
	   });
	   
	   
		

	}

}
