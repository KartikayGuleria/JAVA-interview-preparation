package interviewCodingQuestions;

public class RemoveCharacterFromString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str= "mynameis power";
		String finalString= new String();
		
		finalString=str.replaceAll("m", "");
		
		System.out.println(finalString);
		
		
	}

}
