package javaa;

public class Deadlock extends Thread{

	//note that every object is a lock itself
	//to make threads thread safe we use synchronised blocks which work on concepts of lock
	public static void main(String[] args) {
		
	
	String lock1="power";
	String lock2="shower";
	
	Thread thread1 =new Thread(()->{
		synchronized (lock1) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			synchronized (lock2) {
				System.out.println("inside lock2");
			}
			
		}
		
	},"thread1");
	
	Thread thread2 =new Thread(()->{
		synchronized (lock2) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			synchronized (lock1) {
				System.out.println("inside lock1");
			}
			
	}
	
},"thread2");
	
	thread1.start();
	thread2.start();
	
}
}